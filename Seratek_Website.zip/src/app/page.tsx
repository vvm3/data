  import { Button } from "@/components/ui/button";

export default function App() {
  return <Button>This is button</Button>
}
