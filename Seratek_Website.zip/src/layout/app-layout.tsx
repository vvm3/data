import { JSX, PropsWithChildren } from "react";
import AppHeader from "./app-header";

const AppLayout = ({ children, ...rest }: PropsWithChildren): JSX.Element => {
    return (
        <>
            <AppHeader />
            <div className="mt-20 h-[calc(100vh-80px)] max-h-[calc(100vh-80px)] overflow-auto bg-background">
                {children}
            </div>
        </>
    )
}

export default AppLayout;