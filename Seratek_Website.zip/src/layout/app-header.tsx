import SeratekLogo from "@/components/ui/icons/logo/Logo";
import { JSX } from "react";

const AppHeader = ():JSX.Element => {
    return (
        <div className="fixed top-0 left-0 h-20 flex gap-1 items-center px-12 w-[100vw] bg-[#002A77]">
            <div className="flex items-center"><SeratekLogo /></div>
            <div className="ml-auto">
                <div className="flex flex-col gap-2">
                    {Array(3).fill("_").map(()=><div className="w-[32px] bg-white border border-white"></div>)}
                </div>
            </div>
        </div>
    )
}

export default AppHeader